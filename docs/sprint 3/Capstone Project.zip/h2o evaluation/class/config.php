<?php 
	/**
	 * KEEP THIS IN A SAFE PLACE!
	 * @category	H20 Employee Eval System - Database Config File
	 * @author		Software Engineering - H20 Project
	 * @version		1.0
	 * @see			documentation.html
	 */
	DEFINE('DB_Host', 'den1.mysql4.gear.host'); 
	DEFINE('DB_User', 'morphling'); 
	DEFINE('DB_Pass', 'Uc1B!Tdt~t4J'); 
	DEFINE('DB_Name', 'morphling'); 
	DEFINE('DB_Users_Table', 'morphling.h2o_users');
	DEFINE('DB_Survey_Table', 'morphling.h2o_surveys');
?>
